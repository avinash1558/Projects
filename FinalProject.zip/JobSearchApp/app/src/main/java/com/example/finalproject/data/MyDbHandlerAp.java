package com.example.finalproject.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.finalproject.model.Applyinfo;
import com.example.finalproject.model.JobInfo;
import com.example.finalproject.params.Params;

import java.util.ArrayList;
import java.util.List;

public class MyDbHandlerAp extends SQLiteOpenHelper {
    public MyDbHandlerAp(Context context) {
        super(context, Params.DB_JOBAP, null, Params.DB_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {

        String adcreate = "CREATE TABLE " + Params.TABLE_JOBAP + "("
                + Params.KEY_ID + " INTEGER PRIMARY KEY,"
                + Params.KEY_COMNAME + " TEXT, "
                + Params.KEY_APEMAIL + " TEXT, "
                + Params.KEY_APNAME + " TEXT, "
                + Params.KEY_APPHONE + " TEXT, "
                + Params.KEY_APADDRESS + " TEXT, "
                + Params.KEY_APPINCODE + " TEXT, "
                + Params.KEY_APCITY + " TEXT, "
                + Params.KEY_APGENDER + " TEXT, "
                + Params.KEY_APDATE + " TEXT, "
                + Params.KEY_APDEGREE + " TEXT, "
                + Params.KEY_APFOS + " TEXT "
                + ")";
        Log.d("dbharry", "Query being run is : " + adcreate);
        db.execSQL(adcreate);
    }
    public void addJobAp(Applyinfo Jobinfo){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(Params.KEY_COMNAME, Jobinfo.getApCom());
        values.put(Params.KEY_APEMAIL, Jobinfo.getApemail());
        values.put(Params.KEY_APNAME, Jobinfo.getApname());
        values.put(Params.KEY_APPHONE, Jobinfo.getApphone());
        values.put(Params.KEY_APADDRESS, Jobinfo.getApaddress());
        values.put(Params.KEY_APPINCODE, Jobinfo.getAppincode());
        values.put(Params.KEY_APCITY, Jobinfo.getApcity());
        values.put(Params.KEY_APGENDER, Jobinfo.getApgender());
        values.put(Params.KEY_APDATE, Jobinfo.getApdate());
        values.put(Params.KEY_APDEGREE, Jobinfo.getApdegree());
        values.put(Params.KEY_APFOS, Jobinfo.getApfos());


        db.insert(Params.TABLE_JOBAP, null, values);
        Log.d("CreateAD", "Successfully inserted");
        db.close();
    }

    public int updateJobAp(Applyinfo Jobinfo){

        SQLiteDatabase db = this.getWritableDatabase();
//we have created a writable object of SQLiteDatabase as we have to write(update) contact.

        ContentValues values = new ContentValues();
//in above line of code we have created an object of “Contentvalues”  that stores a set of values
        values.put(Params.KEY_COMNAME, Jobinfo.getApCom());
        values.put(Params.KEY_APEMAIL, Jobinfo.getApemail());
        values.put(Params.KEY_APNAME, Jobinfo.getApname());
        values.put(Params.KEY_APPHONE, Jobinfo.getApphone());
        values.put(Params.KEY_APADDRESS, Jobinfo.getApaddress());
        values.put(Params.KEY_APPINCODE, Jobinfo.getAppincode());
        values.put(Params.KEY_APCITY, Jobinfo.getApcity());
        values.put(Params.KEY_APGENDER, Jobinfo.getApgender());
        values.put(Params.KEY_APDATE, Jobinfo.getApdate());
        values.put(Params.KEY_APDEGREE, Jobinfo.getApdegree());
        values.put(Params.KEY_APFOS, Jobinfo.getApfos());

//the below statement will update the old content of contact to the new one.
        return db.update(Params.TABLE_JOBAP, values, Params.KEY_ID + "=?",
                new String[]{String.valueOf(Jobinfo.getApjobid())});
    }

    public List<Applyinfo> getAllJobAp(){
        List<Applyinfo> adInfoList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Generate the query to read from the database
        String select = "SELECT * FROM " + Params.TABLE_JOBAP;
        Cursor cursor = db.rawQuery(select, null);

        //Loop through now
        if(cursor.moveToFirst()){
            do{
                Applyinfo Admininfo = new Applyinfo();
                Admininfo.setApjobid(Integer.parseInt(cursor.getString(0)));
                Admininfo.setApemail(cursor.getString(1));
                Admininfo.setApCom(cursor.getString(2));
                Admininfo.setApname(cursor.getString(3));
                Admininfo.setApphone(cursor.getString(4));
                Admininfo.setApaddress(cursor.getString(5));
                Admininfo.setAppincode(cursor.getString(6));
                Admininfo.setApcity(cursor.getString(7));
                Admininfo.setApgender(cursor.getString(8));
                Admininfo.setApdate(cursor.getString(9));
                Admininfo.setApdegree(cursor.getString(10));
                Admininfo.setApfos(cursor.getString(11));
                adInfoList.add(Admininfo);
            }while(cursor.moveToNext());
        }
        return adInfoList;
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}