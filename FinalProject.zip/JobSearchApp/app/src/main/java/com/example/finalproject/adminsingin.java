package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.finalproject.data.MyDbHandler;
import com.example.finalproject.data.MyDbHandlerAd;
import com.example.finalproject.model.Admininfo;
import com.example.finalproject.model.UserInfo;

import java.util.List;

public class adminsingin extends AppCompatActivity {

    EditText t1, t2, t3, t4, t5;
    String username;
    String email;
    String phone;
    String password;
    String confirmpassword;
    boolean create;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        create=true;
        setContentView(R.layout.activity_adminsingin);
        MyDbHandlerAd db = new MyDbHandlerAd(adminsingin.this);
        t1 = findViewById(R.id.username);
        t2 = findViewById(R.id.email);
        t3 = findViewById(R.id.phone);
        t4 = findViewById(R.id.password);
        t5 = findViewById(R.id.confirmpassword);

        findViewById(R.id.adddetails).setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                username=t1.getText().toString();
                email=t2.getText().toString();
                phone=t3.getText().toString();
                password=t4.getText().toString();
                confirmpassword=t5.getText().toString();
                List<Admininfo> allAdInfos = db.getAllAdmin();
                for (Admininfo AdminInfo : allAdInfos) {

                    if(email.equals(AdminInfo.getAdemail())){
                        create =false;
                    }
                    if(phone.equals(AdminInfo.getAdphone())) {
                        create = false;
                    }
                }
                if (password.equals(confirmpassword)){
                    if(create==true) {
                        Admininfo user = new Admininfo();
                        user.setAdname(username);
                        user.setAdemail(email);
                        user.setAdphone(phone);
                        user.setAdpassword(password);
                        // Adding a contact to the db
                        db.addAdmin(user);
                        Toast.makeText(adminsingin.this, "Successfully Added", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(getApplicationContext(), adminlogin.class);
                        startActivity(i);
                    }
                    else {
                        Toast.makeText(adminsingin.this, "Already Created", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(getApplicationContext(), adminlogin.class);
                        startActivity(i);
                    }
                }
                else{
                    Toast.makeText(adminsingin.this, "Password Not Matched", Toast.LENGTH_SHORT).show();

                }
            }
        });

        findViewById(R.id.imageBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        findViewById(R.id.textSignIn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
}