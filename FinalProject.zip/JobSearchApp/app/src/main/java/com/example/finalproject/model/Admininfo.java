package com.example.finalproject.model;

public class Admininfo {
    private int adid;
    private String adname;
    private String ademail;
    private String adphone;
    private String adpassword;

    public Admininfo(int adid, String adname, String ademail, String adphone, String adpassword) {
        this.adid = adid;
        this.adname = adname;
        this.ademail = ademail;
        this.adphone = adphone;
        this.adpassword = adpassword;
    }
    public Admininfo(String adname, String ademail, String adphone, String adpassword) {
//        this.adid = adid;
        this.adname = adname;
        this.ademail = ademail;
        this.adphone = adphone;
        this.adpassword = adpassword;
    }

    public Admininfo() {
//        this.adid = adid;
    }

    public int getAdid() {
        return adid;
    }

    public void setAdid(int adid) {
        this.adid = adid;
    }

    public String getAdname() {
        return adname;
    }

    public void setAdname(String adname) {
        this.adname = adname;
    }

    public String getAdemail() {
        return ademail;
    }

    public void setAdemail(String ademail) {
        this.ademail = ademail;
    }

    public String getAdphone() {
        return adphone;
    }

    public void setAdphone(String adphone) {
        this.adphone = adphone;
    }

    public String getAdpassword() {
        return adpassword;
    }

    public void setAdpassword(String adpassword) {
        this.adpassword = adpassword;
    }
}
