package com.example.finalproject.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.finalproject.model.Admininfo;
import com.example.finalproject.model.UserInfo;
import com.example.finalproject.params.Params;

import java.util.ArrayList;
import java.util.List;

public class MyDbHandler extends SQLiteOpenHelper {

    public MyDbHandler(Context context) {
        super(context, Params.DB_NAME, null, Params.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String create = "CREATE TABLE " + Params.TABLE_NAME + "("
                + Params.KEY_ID + " INTEGER PRIMARY KEY,"
                + Params.KEY_USERNAME + " TEXT, "
                + Params.KEY_EMAIL + " TEXT ,"
                + Params.KEY_PHONE + " TEXT ,"
                + Params.KEY_PASSWORD + " TEXT "
                + ")";
        Log.d("dbharry", "Query being run is : " + create);



        db.execSQL(create);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }



    public void addContact(UserInfo userInfo){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(Params.KEY_USERNAME, userInfo.getUsername());
        values.put(Params.KEY_EMAIL, userInfo.getEmail());
        values.put(Params.KEY_PHONE, userInfo.getPhone());
        values.put(Params.KEY_PASSWORD, userInfo.getPassword());


        db.insert(Params.TABLE_NAME, null, values);
        Log.d("Create", "Successfully inserted");
        db.close();


    }



    public int updateContact(UserInfo userInfo){
        SQLiteDatabase db = this.getWritableDatabase();
//we have created a writable object of SQLiteDatabase as we have to write(update) contact.

        ContentValues values = new ContentValues();
//in above line of code we have created an object of “Contentvalues”  that stores a set of values
        values.put(Params.KEY_USERNAME, userInfo.getUsername());
        values.put(Params.KEY_EMAIL, userInfo.getEmail());
        values.put(Params.KEY_PHONE, userInfo.getPhone());
        values.put(Params.KEY_PASSWORD, userInfo.getPassword());

//the below statement will update the old content of contact to the new one.
        return db.update(Params.TABLE_NAME, values, Params.KEY_ID + "=?",
                new String[]{String.valueOf(userInfo.getId())});
    }




    public List<UserInfo> getAllContacts(){
        List<UserInfo> userInfoList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Generate the query to read from the database
        String select = "SELECT * FROM " + Params.TABLE_NAME;
        Cursor cursor = db.rawQuery(select, null);

        //Loop through now
        if(cursor.moveToFirst()){
            do{
                UserInfo userInfo = new UserInfo();
                userInfo.setId(Integer.parseInt(cursor.getString(0)));
                userInfo.setUsername(cursor.getString(1));
                userInfo.setEmail(cursor.getString(2));
                userInfo.setPhone(cursor.getString(3));
                userInfo.setPassword(cursor.getString(4));
                userInfoList.add(userInfo);
            }while(cursor.moveToNext());
        }
        return userInfoList;
    }



}
