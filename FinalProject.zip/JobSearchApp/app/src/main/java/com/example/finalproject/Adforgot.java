package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.finalproject.data.MyDbHandler;
import com.example.finalproject.data.MyDbHandlerAd;
import com.example.finalproject.model.Admininfo;
import com.example.finalproject.model.UserInfo;

import java.util.List;

public class Adforgot extends AppCompatActivity {
    EditText t1, t2, t3;
    String email;
    int id;
    String password;
    boolean run;
    String phone;
    String username;
    String confirmpassword;
    MyDbHandlerAd db = new MyDbHandlerAd(Adforgot.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adforgot);
        t1 = findViewById(R.id.email);
        t2 = findViewById(R.id.password);
        t3 = findViewById(R.id.confirmpassword);
        findViewById(R.id.Adforgot).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                email = t1.getText().toString();
                password = t2.getText().toString();
                confirmpassword = t3.getText().toString();
                int len = Integer.parseInt(Integer.toString(password.length()));
                if (len > 3) {
                    if (password.equals(confirmpassword)) {
                        List<Admininfo> allAdInfos = db.getAllAdmin();

                        for (Admininfo AdminInfo : allAdInfos) {


                            if (email.equals(AdminInfo.getAdemail())) {
                                username = AdminInfo.getAdname();
                                phone = AdminInfo.getAdphone();
                                id = AdminInfo.getAdid();
                                run = true;
                            }

                        }
                        if (run == true) {

                            Admininfo up = new Admininfo();
                            up.setAdid(id);
                            up.setAdname(username);
                            up.setAdemail(email);
                            up.setAdphone(phone);
                            up.setAdpassword(password);
                            int affectedRows = db.updateAdmin(up);
                            Toast.makeText(Adforgot.this, "Successfully Changed", Toast.LENGTH_SHORT).show();

                            Intent i = new Intent(getApplicationContext(), adminlogin.class);
                            startActivity(i);
                        } else {
                            Toast.makeText(Adforgot.this, "not have", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(Adforgot.this, "Enter correct password", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(Adforgot.this, "Please Enter Details", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}