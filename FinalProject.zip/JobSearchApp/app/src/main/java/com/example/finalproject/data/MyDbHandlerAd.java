package com.example.finalproject.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import com.example.finalproject.model.Admininfo;
import com.example.finalproject.params.Params;

import java.util.ArrayList;
import java.util.List;

public class MyDbHandlerAd extends SQLiteOpenHelper {
    public MyDbHandlerAd(Context context) {
        super(context, Params.DB_ADNAME, null, Params.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String adcreate = "CREATE TABLE " + Params.TABLE_ADNAME + "("
                + Params.KEY_ID + " INTEGER PRIMARY KEY,"
                + Params.KEY_ADNAME + " TEXT, "
                + Params.KEY_ADEMAIL + " TEXT ,"
                + Params.KEY_ADPHONE + " TEXT ,"
                + Params.KEY_ADPASSWORD + " TEXT "
                + ")";
        Log.d("dbharry", "Query being run is : " + adcreate);
        db.execSQL(adcreate);
    }
    public void addAdmin(Admininfo adminInfo){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(Params.KEY_ADNAME, adminInfo.getAdname());
        values.put(Params.KEY_ADEMAIL, adminInfo.getAdemail());
        values.put(Params.KEY_ADPHONE, adminInfo.getAdphone());
        values.put(Params.KEY_ADPASSWORD, adminInfo.getAdpassword());


        db.insert(Params.TABLE_ADNAME, null, values);
        Log.d("CreateAD", "Successfully inserted");
        db.close();
    }
    public int updateAdmin(Admininfo admininfo){
        SQLiteDatabase db = this.getWritableDatabase();
//we have created a writable object of SQLiteDatabase as we have to write(update) contact.

        ContentValues values = new ContentValues();
//in above line of code we have created an object of “Contentvalues”  that stores a set of values
        values.put(Params.KEY_ADNAME, admininfo.getAdname());
        values.put(Params.KEY_ADEMAIL, admininfo.getAdemail());
        values.put(Params.KEY_ADPHONE, admininfo.getAdphone());
        values.put(Params.KEY_ADPASSWORD, admininfo.getAdpassword());

//the below statement will update the old content of contact to the new one.
        return db.update(Params.TABLE_ADNAME, values, Params.KEY_ID + "=?",
                new String[]{String.valueOf(admininfo.getAdid())});
    }
    public List<Admininfo> getAllAdmin(){
        List<Admininfo> adInfoList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Generate the query to read from the database
        String select = "SELECT * FROM " + Params.TABLE_ADNAME;
        Cursor cursor = db.rawQuery(select, null);

        //Loop through now
        if(cursor.moveToFirst()){
            do{
                Admininfo Admininfo = new Admininfo();
                Admininfo.setAdid(Integer.parseInt(cursor.getString(0)));
                Admininfo.setAdname(cursor.getString(1));
                Admininfo.setAdemail(cursor.getString(2));
                Admininfo.setAdphone(cursor.getString(3));
                Admininfo.setAdpassword(cursor.getString(4));
                adInfoList.add(Admininfo);
            }while(cursor.moveToNext());
        }
        return adInfoList;
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
