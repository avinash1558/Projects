package com.example.finalproject.model;

public class JobInfo {
    private int jobid;
    private String comname;
    private String jobname;
    private String jobdetails;
    private String jobplace;
    private String jobsalary;

    public JobInfo(int jobid, String comname, String jobname, String jobdetails, String jobplace, String jobsalary) {
        this.jobid = jobid;
        this.comname = comname;
        this.jobname = jobname;
        this.jobdetails = jobdetails;
        this.jobplace = jobplace;
        this.jobsalary = jobsalary;
    }
    public JobInfo( String comname, String jobname, String jobdetails, String jobplace, String jobsalary) {
//        this.jobid = jobid;
        this.comname = comname;
        this.jobname = jobname;
        this.jobdetails = jobdetails;
        this.jobplace = jobplace;
        this.jobsalary = jobsalary;
    }



    public JobInfo() {
//        this.jobid = jobid;
    }

    public int getJobid() {
        return jobid;
    }

    public void setJobid(int jobid) {
        this.jobid = jobid;
    }

    public String getComname() {
        return comname;
    }

    public void setComname(String comname) {
        this.comname = comname;
    }

    public String getJobname() {
        return jobname;
    }

    public void setJobname(String jobname) {
        this.jobname = jobname;
    }

    public String getJobdetails() {
        return jobdetails;
    }

    public void setJobdetails(String jobdetails) {
        this.jobdetails = jobdetails;
    }

    public String getJobplace() {
        return jobplace;
    }

    public void setJobplace(String jobplace) {
        this.jobplace = jobplace;
    }

    public String getJobsalary() {
        return jobsalary;
    }

    public void setJobsalary(String jobsalary) {
        this.jobsalary = jobsalary;
    }
}
