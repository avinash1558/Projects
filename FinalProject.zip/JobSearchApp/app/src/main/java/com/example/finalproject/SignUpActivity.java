package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.finalproject.data.MyDbHandler;
import com.example.finalproject.model.UserInfo;

import java.util.List;

public class SignUpActivity extends AppCompatActivity {
    EditText t1, t2, t3, t4, t5;
    String username;
    String email;
    String phone;
    String password;
    String confirmpassword;
    boolean create;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        create=true;
        setContentView(R.layout.activity_sign_up);
        MyDbHandler db = new MyDbHandler(SignUpActivity.this);
        t1 = findViewById(R.id.username);
        t2 = findViewById(R.id.email);
        t3 = findViewById(R.id.phone);
        t4 = findViewById(R.id.password);
        t5 = findViewById(R.id.confirmpassword);

        findViewById(R.id.adddetails).setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                username=t1.getText().toString();
                email=t2.getText().toString();
                phone=t3.getText().toString();
                password=t4.getText().toString();
                confirmpassword=t5.getText().toString();
                List<UserInfo> allUserInfos = db.getAllContacts();
                for (UserInfo userInfo : allUserInfos) {
                    Log.d("dbharry", "\nId: " + userInfo.getId() + "\n" +
                            "Name: " + userInfo.getUsername() + "\n" +
                            "Name: " + userInfo.getEmail() + "\n" +
                            "Name: " + userInfo.getPhone() + "\n" +
                            "Phone Number: " + userInfo.getPassword() + "\n");
                    if(email.equals(userInfo.getEmail())){
                        create =false;
                    }
                    if(phone.equals(userInfo.getPhone())) {
                        create = false;
                    }
                }
                if (password.equals(confirmpassword)){
                    if(create==true) {
                        UserInfo user = new UserInfo();
                        user.setUsername(username);
                        user.setEmail(email);
                        user.setPhone(phone);
                        user.setPassword(password);
                        // Adding a contact to the db
                        db.addContact(user);
                        Toast.makeText(SignUpActivity.this, "Successfully added", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(getApplicationContext(), LoginActivity.class);
                        startActivity(i);
                    }
                    else {
                        Toast.makeText(SignUpActivity.this, "Already created", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(getApplicationContext(), LoginActivity.class);
                        startActivity(i);
                    }
                }
                else{
                    Toast.makeText(SignUpActivity.this, "Password and Confirm Password are not matched", Toast.LENGTH_SHORT).show();

                }
            }
        });

        findViewById(R.id.imageBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        findViewById(R.id.textSignIn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
}