package com.example.finalproject.model;

public class Applyinfo {
    private int apjobid;
    private String apCom;
    private String apemail;
    private String apname;
    private String apphone;
    private String apaddress;
    private String appincode;
    private String apcity;
    private String apgender;
    private String apdate;
    private String apdegree;
    private String apfos;

    public Applyinfo(int apjobid,String apCom, String apemail, String apname, String apphone, String apaddress, String appincode, String apcity, String apgender, String apdate, String apdegree, String apfos) {
        this.apCom = apCom;
        this.apjobid = apjobid;
        this.apemail = apemail;
        this.apname = apname;
        this.apphone = apphone;
        this.apaddress = apaddress;
        this.appincode = appincode;
        this.apcity = apcity;
        this.apgender = apgender;
        this.apdate = apdate;
        this.apdegree = apdegree;
        this.apfos = apfos;
    }
    public Applyinfo( String apCom,String apemail, String apname, String apphone, String apaddress, String appincode, String apcity, String apgender, String apdate, String apdegree, String apfos) {
        this.apCom = apCom;
        this.apemail = apemail;
        this.apname = apname;
        this.apphone = apphone;
        this.apaddress = apaddress;
        this.appincode = appincode;
        this.apcity = apcity;
        this.apgender = apgender;
        this.apdate = apdate;
        this.apdegree = apdegree;
        this.apfos = apfos;
    }

    public Applyinfo() {
//        this.apjobid = apjobid;
    }

    public int getApjobid() {
        return apjobid;
    }

    public void setApjobid(int apjobid) {
        this.apjobid = apjobid;
    }

    public String getApCom() {
        return apCom;
    }

    public void setApCom(String apCom) {
        this.apCom = apCom;
    }

    public String getApemail() {
        return apemail;
    }

    public void setApemail(String apemail) {
        this.apemail = apemail;
    }

    public String getApname() {
        return apname;
    }

    public void setApname(String apname) {
        this.apname = apname;
    }

    public String getApphone() {
        return apphone;
    }

    public void setApphone(String apphone) {
        this.apphone = apphone;
    }

    public String getApaddress() {
        return apaddress;
    }

    public void setApaddress(String apaddress) {
        this.apaddress = apaddress;
    }

    public String getAppincode() {
        return appincode;
    }

    public void setAppincode(String appincode) {
        this.appincode = appincode;
    }

    public String getApcity() {
        return apcity;
    }

    public void setApcity(String apcity) {
        this.apcity = apcity;
    }

    public String getApgender() {
        return apgender;
    }

    public void setApgender(String apgender) {
        this.apgender = apgender;
    }

    public String getApdate() {
        return apdate;
    }

    public void setApdate(String apdate) {
        this.apdate = apdate;
    }

    public String getApdegree() {
        return apdegree;
    }

    public void setApdegree(String apdegree) {
        this.apdegree = apdegree;
    }

    public String getApfos() {
        return apfos;
    }

    public void setApfos(String apfos) {
        this.apfos = apfos;
    }
}