package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

//import com.example.finalproject.data.MyDbHandler;
import com.example.finalproject.data.MyDbHandlerAd;
import com.example.finalproject.model.Admininfo;
//import com.example.finalproject.model.UserInfo;

import java.util.List;

public class adminlogin extends AppCompatActivity {

    EditText t1, t2;String email;String password;
    String username;
    MyDbHandlerAd db = new MyDbHandlerAd(adminlogin.this);
    boolean create,check;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminlogin);

        t1 = findViewById(R.id.username);
        t2= findViewById(R.id.password);
        findViewById(R.id.signin).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                email=t1.getText().toString();
                password=t2.getText().toString();
                List<Admininfo> allAdInfos = db.getAllAdmin();

                for (Admininfo AdminInfo : allAdInfos) {


                    if(email.equals(AdminInfo.getAdemail()) && password.equals(AdminInfo.getAdpassword())){
                        username=AdminInfo.getAdname();
                        create =true;

                    }
                    if(email.equals(AdminInfo.getAdemail())){
                        check=true;
                    }

                }


                if (create == true) {
                    Toast.makeText(adminlogin.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(getApplicationContext(),jobAdd.class);
                    i.putExtra("comname",username);
                    startActivity(i);

                } else {
                    if(check==true){
                        Toast.makeText(adminlogin.this, "Enter Correct Password", Toast.LENGTH_SHORT).show();

                    }
                    else {
                        Toast.makeText(adminlogin.this, "Please Create Account", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });




        findViewById(R.id.textAdCreateAccount).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),adminsingin.class));
            }
        });

        // this code for dashboard testing
        findViewById(R.id.textAdForgetPassword).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),Adforgot.class));
            }
        });


    }
}