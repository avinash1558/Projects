package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
//import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
//import android.widget.ListView;

import com.example.finalproject.data.MyDbHandlerJob;
import com.example.finalproject.model.JobInfo;

import java.util.ArrayList;
import java.util.List;

public class joblist extends AppCompatActivity {
    RecyclerView recyclerView;
    Jobbox recyclerViewAdapter;
    ArrayList<JobInfo> jobinfo;
    ArrayAdapter<String> arrayAdapter;
    MyDbHandlerJob AD = new MyDbHandlerJob(joblist.this);
    ArrayList<String> al=new ArrayList<>();
//String str[100];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_joblist);

        findViewById(R.id.backImageMenu).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        recyclerView=findViewById(R.id.rec);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        jobinfo =new ArrayList<>();
        List<JobInfo> allUserInfos = AD.getAllJob();
        for (JobInfo userInfo : allUserInfos) {
          jobinfo.add(userInfo);
        }

        recyclerViewAdapter = new Jobbox(joblist.this,jobinfo);
        recyclerView.setAdapter(recyclerViewAdapter);


    }

}