package com.example.finalproject;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject.model.JobInfo;

import java.util.List;

public class Jobbox extends RecyclerView.Adapter<Jobbox.ViewHolder> {

    Context context;
    List<JobInfo> joblist;

    public Jobbox(Context context, List<JobInfo> joblist) {
        this.context = context;
        this.joblist = joblist;
    }

    @NonNull
    @Override
    public Jobbox.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.jobbox, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Jobbox.ViewHolder holder, int position) {
        JobInfo jobInfo = joblist.get(position);
        holder.btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context.getApplicationContext(),Apply.class);
                i.putExtra("comname",jobInfo.getComname());
                context.startActivity(i);

            }
        });
        holder.t2.setText(jobInfo.getComname());
        holder.t1.setText(jobInfo.getJobname());
        holder.t3.setText(jobInfo.getJobdetails());
        holder.t4.setText(jobInfo.getJobplace());
        holder.t5.setText(jobInfo.getJobsalary());
    }

    @Override
    public int getItemCount() {
        return joblist.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView t1, t2, t3, t4, t5;
        Button btn;

        public ViewHolder(@NonNull View itemView) {

            super(itemView);
            itemView.setOnClickListener(this);
            btn = itemView.findViewById(R.id.button);
            t1 = itemView.findViewById(R.id.textView);
            t2 = itemView.findViewById(R.id.textView5);
            t3 = itemView.findViewById(R.id.textView3);
            t4 = itemView.findViewById(R.id.textView2);
            t5 = itemView.findViewById(R.id.textView4);
        }

        @Override
        public void onClick(View view) {

        }
    }
}