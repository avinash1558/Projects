package com.example.finalproject.params;

public class Params {

    public static final int DB_VERSION = 2;
    public static final String DB_NAME = "userinfos_db";
    public static final String TABLE_NAME = "userdetail_table";

    public static final String DB_ADNAME = "admininfos_db";
    public static final String TABLE_ADNAME = "admindetail_table";
    public static final String DB_JOB = "jobinfos_db";
    public static final String TABLE_JOB = "jobdetail_table";

    public static final String DB_JOBAP = "applyinfo_db";
    public static final String TABLE_JOBAP = "apdetail_table";


    //Keys of our table in db
    public static final String KEY_ID = "id";
    public static final String KEY_USERNAME = "username";
    public static final String KEY_EMAIL = "email";
    public static final String KEY_PHONE = "phone";
    public static final String KEY_PASSWORD = "password";


    //    public static final String KEY_ID = "id";
    public static final String KEY_ADNAME = "adname";
    public static final String KEY_ADEMAIL = "ademail";
    public static final String KEY_ADPHONE = "adphone";
    public static final String KEY_ADPASSWORD = "adpassword";

    public static final String KEY_COMNAME = "comname";
    public static final String KEY_JOBNAME = "jobname";
    public static final String KEY_JOBDETAILS = "jobdetails";
    public static final String KEY_JOBPLACE = "jobplace";
    public static final String KEY_JOBSALARY = "jobsalary";



    public static final String KEY_APEMAIL = "apemail";
    public static final String KEY_APNAME = "apname";
    public static final String KEY_APPHONE = "apphone";
    public static final String KEY_APADDRESS = "apaddress";
    public static final String KEY_APPINCODE = "appincode";
    public static final String KEY_APCITY = "apcity";
    public static final String KEY_APGENDER = "apgender";
    public static final String KEY_APDATE = "apdate";
    public static final String KEY_APDEGREE = "apdegree";
    public static final String KEY_APFOS = "apfos";


}