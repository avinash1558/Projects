package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.finalproject.data.MyDbHandler;
import com.example.finalproject.model.UserInfo;

import java.util.List;

public class forgot extends AppCompatActivity {
    EditText t1, t2, t3;
    String email;
    boolean run;
    int id;
    String password;
    String phone;
    String username;
    String confirmpassword;
    MyDbHandler db = new MyDbHandler(forgot.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot);
        t1 = findViewById(R.id.email);
        t2 = findViewById(R.id.password);
        t3 = findViewById(R.id.confirmpassword);
        findViewById(R.id.forgot).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                email = t1.getText().toString();
                password = t2.getText().toString();
                confirmpassword = t3.getText().toString();
                int len = Integer.parseInt(Integer.toString(password.length()));
                if (len > 3) {
                    if (password.equals(confirmpassword)) {
                        List<UserInfo> allUserInfos = db.getAllContacts();

                        for (UserInfo userInfo : allUserInfos) {


                            if (email.equals(userInfo.getEmail())) {
                                Log.d("dbharry", "\nId: " + userInfo.getId() + "\n" +
                                        "Username " + userInfo.getUsername() + "\n" +
                                        "Email" + userInfo.getEmail() + "\n" +
                                        "Phone" + userInfo.getPhone() + "\n" +
                                        "Password" + userInfo.getPassword() + "\n");
                                username = userInfo.getUsername();
                                phone = userInfo.getPhone();
                                id = userInfo.getId();
                                run = true;
                            }

                        }
                        if (run == true) {
                            UserInfo up = new UserInfo();
                            up.setId(id);
                            up.setUsername(username);
                            up.setEmail(email);
                            up.setPhone(phone);
                            up.setPassword(password);
                            int affectedRows = db.updateContact(up);
                            Toast.makeText(forgot.this, "Password Changed", Toast.LENGTH_SHORT).show();

                            Intent i = new Intent(getApplicationContext(), LoginActivity.class);
                            startActivity(i);

                        } else {
                            Toast.makeText(forgot.this, "Create Account", Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        Toast.makeText(forgot.this, "Enter correct password", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(forgot.this, "Please Enter Details", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}