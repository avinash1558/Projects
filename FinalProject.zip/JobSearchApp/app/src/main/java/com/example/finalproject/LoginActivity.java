package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;
//import android.util.Log;
import android.view.View;
import android.widget.EditText;
//import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.finalproject.data.MyDbHandler;
import com.example.finalproject.model.UserInfo;

//import java.io.BufferedReader;
//import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
//import java.io.InputStreamReader;
import java.util.List;

public class LoginActivity extends AppCompatActivity {
    EditText t1, t2;
    String email;
    String password, username;
    FileOutputStream fos;
    String file = "user.txt";
    MyDbHandler db = new MyDbHandler(LoginActivity.this);
    boolean create, check;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
//        this is for the user login checking username or password
        t1 = findViewById(R.id.username);
        t2 = findViewById(R.id.password);
        findViewById(R.id.signin).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                email = t1.getText().toString();
                password = t2.getText().toString();
                List<UserInfo> allUserInfos = db.getAllContacts();
                for (UserInfo userInfo : allUserInfos) {
                    if (email.equals(userInfo.getEmail()) && password.equals(userInfo.getPassword())) {
                        create = true;
                        username = userInfo.getUsername();
                    }
                    if (email.equals(userInfo.getEmail())) {
                        check = true;
                    }
                }
                if (create == true) {
                    String str = username;
                    try {
                        fos = openFileOutput(file, MODE_PRIVATE);
                        fos.write(str.getBytes());
                    } catch (FileNotFoundException e) {
                        throw new RuntimeException(e);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    } finally {
                        if (fos != null) {
                            try {
                                fos.close();
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    }
                    Toast.makeText(LoginActivity.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(i);
                } else {
                    if (check == true) {
                        Toast.makeText(LoginActivity.this, "Enter correct password", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(LoginActivity.this, "Please Enter Username and Password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
//        this is for user sign page
        findViewById(R.id.textCreateAccount).
                setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        startActivity(new Intent(getApplicationContext(), SignUpActivity.class));
                    }
                });
        // this code for dashboard testing
        findViewById(R.id.textForgetPassword).
                setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        startActivity(new Intent(getApplicationContext(), forgot.class));
                    }
                });
    }
}

