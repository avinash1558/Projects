package com.example.finalproject;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
//import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;

import com.example.finalproject.data.MyDbHandler;
import com.example.finalproject.data.MyDbHandlerAd;
import com.example.finalproject.data.MyDbHandlerAp;
import com.example.finalproject.data.MyDbHandlerJob;
//import com.example.finalproject.model.Admininfo;
import com.example.finalproject.model.Applyinfo;
//import com.example.finalproject.model.JobInfo;
//import com.example.finalproject.model.UserInfo;
import com.google.android.material.navigation.NavigationView;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    String file = "user.txt";
    FileOutputStream fos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


//        This All Are The DataBase Handler
        MyDbHandler db = new MyDbHandler(MainActivity.this);
        MyDbHandlerAp Ap = new MyDbHandlerAp(MainActivity.this);
        MyDbHandlerAd ADdb = new MyDbHandlerAd(MainActivity.this);
        MyDbHandlerJob AD = new MyDbHandlerJob(MainActivity.this);
//          This Code for Apply for the job
        List<Applyinfo> allUserInfos = Ap.getAllJobAp();
        for (Applyinfo userInfo : allUserInfos) {
            Log.d("Apply Info", "\nId: " + userInfo.getApjobid() + "\n" +
                    "Email Id : " + userInfo.getApCom() + "\n" +
                    "Company Name : " + userInfo.getApemail() + "\n" +
                    "Username : " + userInfo.getApname()+ "\n" +
                    "Phone Number : " + userInfo.getApphone() + "\n" +
                    "Address : " + userInfo.getApaddress()+ "\n" +
                    "Pincode : " + userInfo.getAppincode() + "\n" +
                    "City : " + userInfo.getApcity() + "\n" +
                    "Gender : " + userInfo.getApgender() + "\n" +
                    "Date : " + userInfo.getApdate() + "\n" +
                    "Degree : " + userInfo.getApdegree() + "\n" +
                    "Field Of Study " + userInfo.getApfos() + "\n" +
                    "\n");
        }
//        this is for drawer layout code
        final DrawerLayout drawerLayout = findViewById(R.id.drawerLayout);
        findViewById(R.id.imageMenu).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
//          this is for navigation bar
        NavigationView navigationView = findViewById(R.id.navigationView);
        navigationView.setItemIconTintList(null);
        NavController navController = Navigation.findNavController(this, R.id.navHostFragment);
        NavigationUI.setupWithNavController(navigationView, navController);
        TextView textTitle = findViewById(R.id.textTitle);
        navController.addOnDestinationChangedListener(new NavController.OnDestinationChangedListener() {
            @Override
            public void onDestinationChanged(@NonNull NavController controller, @NonNull NavDestination destination, @Nullable Bundle arguments) {
                textTitle.setText(destination.getLabel());
            }
        });
    }

    @Override
    protected void onDestroy() {
        String str="";
        try {
            fos = openFileOutput(file, MODE_PRIVATE);
            fos.write(str.getBytes());
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        super.onDestroy();
    }
}