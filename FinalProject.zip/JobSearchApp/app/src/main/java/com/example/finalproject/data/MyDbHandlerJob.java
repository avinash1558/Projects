package com.example.finalproject.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.finalproject.model.Admininfo;
import com.example.finalproject.model.JobInfo;
import com.example.finalproject.params.Params;

import java.util.ArrayList;
import java.util.List;

public class MyDbHandlerJob extends SQLiteOpenHelper {
    public MyDbHandlerJob(Context context) {
        super(context, Params.DB_JOB, null, Params.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String adcreate = "CREATE TABLE " + Params.TABLE_JOB + "("
                + Params.KEY_ID + " INTEGER PRIMARY KEY,"
                + Params.KEY_COMNAME + " TEXT, "
                + Params.KEY_JOBNAME + " TEXT, "
                + Params.KEY_JOBDETAILS + " TEXT ,"
                + Params.KEY_JOBPLACE + " TEXT ,"
                + Params.KEY_JOBSALARY + " TEXT "
                + ")";
        Log.d("dbharry", "Query being run is : " + adcreate);
        db.execSQL(adcreate);
    }

    public void addJob(JobInfo Jobinfo){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(Params.KEY_COMNAME, Jobinfo.getComname());
        values.put(Params.KEY_JOBNAME, Jobinfo.getJobname());
        values.put(Params.KEY_JOBDETAILS, Jobinfo.getJobdetails());
        values.put(Params.KEY_JOBPLACE, Jobinfo.getJobplace());
        values.put(Params.KEY_JOBSALARY, Jobinfo.getJobsalary());


        db.insert(Params.TABLE_JOB, null, values);
        Log.d("CreateAD", "Successfully inserted");
        db.close();
    }

    public int updateJob(JobInfo Jobinfo){

        SQLiteDatabase db = this.getWritableDatabase();
//we have created a writable object of SQLiteDatabase as we have to write(update) contact.

        ContentValues values = new ContentValues();
//in above line of code we have created an object of “Contentvalues”  that stores a set of values
        values.put(Params.KEY_COMNAME, Jobinfo.getComname());
        values.put(Params.KEY_JOBNAME, Jobinfo.getJobname());
        values.put(Params.KEY_JOBDETAILS, Jobinfo.getJobdetails());
        values.put(Params.KEY_JOBPLACE, Jobinfo.getJobplace());
        values.put(Params.KEY_JOBSALARY, Jobinfo.getJobsalary());

//the below statement will update the old content of contact to the new one.
        return db.update(Params.TABLE_JOB, values, Params.KEY_ID + "=?",
                new String[]{String.valueOf(Jobinfo.getJobid())});
    }

    public List<JobInfo> getAllJob(){
        List<JobInfo> adInfoList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Generate the query to read from the database
        String select = "SELECT * FROM " + Params.TABLE_JOB;
        Cursor cursor = db.rawQuery(select, null);

        //Loop through now
        if(cursor.moveToFirst()){
            do{
                JobInfo Admininfo = new JobInfo();
                Admininfo.setJobid(Integer.parseInt(cursor.getString(0)));
                Admininfo.setComname(cursor.getString(1));
                Admininfo.setJobname(cursor.getString(2));
                Admininfo.setJobdetails(cursor.getString(3));
                Admininfo.setJobplace(cursor.getString(4));
                Admininfo.setJobsalary(cursor.getString(5));
                adInfoList.add(Admininfo);
            }while(cursor.moveToNext());
        }
        return adInfoList;
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}