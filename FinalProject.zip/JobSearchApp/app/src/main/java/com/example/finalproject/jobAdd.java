package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.finalproject.data.MyDbHandlerJob;
import com.example.finalproject.model.JobInfo;
import com.example.finalproject.model.UserInfo;

import java.util.List;

public class jobAdd extends AppCompatActivity {
    MyDbHandlerJob AD = new MyDbHandlerJob(jobAdd.this);
    boolean check;
    int id;
    String jobname, jobdetails, jobplace, jobsalary, username, comname;
    EditText t1, t2, t3, t4, t5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_add);

        t1 = findViewById(R.id.username);
        t2 = findViewById(R.id.jobname);
        t3 = findViewById(R.id.jobdetails);
        t4 = findViewById(R.id.jobplace);
        t5 = findViewById(R.id.jobsalary);

        List<JobInfo> allUser = AD.getAllJob();


        comname = getIntent().getExtras().getString("comname");
        comname=comname.toString();
        t1.setText(comname);
        for (JobInfo userInfo : allUser) {
            if (comname.equals(userInfo.getComname())) {
                t2.setText(userInfo.getJobname());
                t3.setText(userInfo.getJobdetails());
                t4.setText(userInfo.getJobplace());
                t5.setText(userInfo.getJobsalary());
            }
        }
        findViewById(R.id.add).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(jobAdd.this, "Added Successfully", Toast.LENGTH_SHORT).show();

                username = t1.getText().toString();
                jobname = t2.getText().toString();
                jobdetails = t3.getText().toString();
                jobplace = t4.getText().toString();
                jobsalary = t5.getText().toString();
                List<JobInfo> allUserInfos = AD.getAllJob();

                for (JobInfo userInfo : allUserInfos) {
                    if (username.equals(userInfo.getComname())) {
                        id = userInfo.getJobid();
                        check = true;
                    }
                }
                if (check == true) {

                    JobInfo up = new JobInfo();
                    up.setJobid(id);
                    up.setComname(username);
                    up.setJobname(jobname);
                    up.setJobdetails(jobdetails);
                    up.setJobplace(jobplace);
                    up.setJobsalary(jobsalary);
                    AD.updateJob(up);
                    Toast.makeText(jobAdd.this, "update", Toast.LENGTH_SHORT).show();
                } else {

                    JobInfo user = new JobInfo();
                    user.setComname(username);
                    user.setJobname(jobname);
                    user.setJobdetails(jobdetails);
                    user.setJobplace(jobplace);
                    user.setJobsalary(jobsalary);
                    // Adding a contact to the db
                    AD.addJob(user);
                    Toast.makeText(jobAdd.this, "Successfully Added", Toast.LENGTH_SHORT).show();
                }
            }

        });
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(getApplicationContext(),MainActivity.class);
//                i.putExtra("comname",email);
                startActivity(i);
            }
        });
        findViewById(R.id.imageBack2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


    }
}
