package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.finalproject.data.MyDbHandlerAp;
import com.example.finalproject.model.Admininfo;
import com.example.finalproject.model.Applyinfo;

import java.util.List;

public class Apply extends AppCompatActivity {
    MyDbHandlerAp Ap = new MyDbHandlerAp(Apply.this);
    EditText t1, t2, t3, t4, t5, t6, t7, t8, t9, t10;
    RadioGroup rg;
    boolean check;
    String comname, apemail, apname, apphone, apaddress, appincode, apcity, apgender, apdate, apdegree, apfos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apply);
        Applyinfo harry = new Applyinfo();
//        TextView tv = ;
        findViewById(R.id.TV_btnnext).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                comname = getIntent().getExtras().getString("comname");


                t1 = findViewById(R.id.ET_email);
                apemail = t1.getText().toString();
                t2 = findViewById(R.id.ET_name);
                apname = t2.getText().toString();
                t3 = findViewById(R.id.ET_mobie);
                apphone = t3.getText().toString();
                t4 = findViewById(R.id.ET_address);
                apaddress = t4.getText().toString();
                t5 = findViewById(R.id.ET_pincode);
                appincode = t5.getText().toString();
                t6 = findViewById(R.id.ET_currentcity);
                apcity = t6.getText().toString();
                rg = findViewById(R.id.Radio_gender);
                int checkedRadioButtonId = rg.getCheckedRadioButtonId();

                if (checkedRadioButtonId == R.id.Radio_female) {
                    apgender = "2";


                } else {
                    apgender = "1";
                }

                t7 = findViewById(R.id.ET_dob);
                apdate = t7.getText().toString();
                t8 = findViewById(R.id.ET_degree);
                apdegree = t8.getText().toString();
                t9 = findViewById(R.id.ET_fos);
                apfos = t9.getText().toString();
                List<Applyinfo> allAdInfos = Ap.getAllJobAp();
                for (Applyinfo AdminInfo : allAdInfos) {

                    if (apname.equals(AdminInfo.getApname()) && apemail.equals(AdminInfo.getApemail())) {
                        check = true;
                    }
                }
                if (check == true) {
                    Toast.makeText(Apply.this, "Already Applied", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                } else {
//                            harry.setApjobid(1);
                    harry.setApCom(comname);
                    harry.setApemail(apemail);
                    harry.setApname(apname);
                    harry.setApphone(apphone);
                    harry.setApaddress(apaddress);
                    harry.setAppincode(appincode);
                    harry.setApcity(apcity);
                    harry.setApgender(apgender);
                    harry.setApdate(apdate);
                    harry.setApdegree(apdegree);
                    harry.setApfos(apfos);


                    // Adding a contact to the db
                    Ap.addJobAp(harry);
                    Toast.makeText(Apply.this, "Applied", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                }
            }
        });

    }
}